CREATE SCHEMA ex51;

-- Delete Section
DROP TABLE ex51.Dependent;
DROP TABLE ex51.Works_on;
DROP TABLE ex51.Project;
DROP TABLE ex51.Dept_locations;
ALTER TABLE ex51.Employee
	DROP CONSTRAINT TRABALHA
DROP TABLE ex51.Department;
DROP TABLE ex51.Employee;

-- Init Section
CREATE TABLE ex51.Employee(
	Fname		VARCHAR(20),
	Minit		CHAR,
	LName		VARCHAR(20),
	Ssn			INT,
	Bdate		DATE,
	Address		VARCHAR(20),
	Sex			CHAR,
	Salary		INTEGER,
	Super_ssn	INT,
	Dno			INT,

	PRIMARY KEY (Ssn),
	FOREIGN KEY (Super_ssn) REFERENCES ex51.employee(Ssn)
);

CREATE TABLE ex51.Department(
	Dname			VARCHAR(20),
	Dnumber			INT,
	Mgr_ssn			INT,
	Mgr_start_date	DATE,

	PRIMARY KEY (Dnumber),
	FOREIGN KEY (Mgr_ssn) REFERENCES ex51.Employee(Ssn)
);

ALTER TABLE ex51.Employee
	ADD CONSTRAINT TRABALHA FOREIGN KEY (Dno) REFERENCES ex51.Department(Dnumber);

CREATE TABLE ex51.Dept_locations(
	Dnumber		INT,
	Dlocation	VARCHAR(20),
	
	PRIMARY KEY (Dnumber,Dlocation),
	FOREIGN KEY (Dnumber) REFERENCES ex51.Department(Dnumber)
);

CREATE TABLE ex51.Project(
	Pname		VARCHAR(20),
	Pnumber		INT,
	Plocation	VARCHAR(20),
	Dnum		INT,
	
	PRIMARY KEY (Pnumber),
	FOREIGN KEY (Dnum) REFERENCES ex51.Department(Dnumber)
);

CREATE TABLE ex51.Works_on(
	Essn		INT,
	Pno			INT,
	Hours		INT,
	
	PRIMARY KEY (Essn,Pno),
	FOREIGN KEY (Essn) REFERENCES ex51.Employee(Ssn),
	FOREIGN KEY (Pno) REFERENCES ex51.Project(Pnumber)
);

CREATE TABLE ex51.Dependent(
	Essn			INT,
	Dependent_name	VARCHAR(20),
	Sex				CHAR,
	Bdate			DATE,
	Relationship	VARCHAR(20),
	
	PRIMARY KEY (Essn,Dependent_name),
	FOREIGN KEY (Essn) REFERENCES ex51.employee(Ssn)
);