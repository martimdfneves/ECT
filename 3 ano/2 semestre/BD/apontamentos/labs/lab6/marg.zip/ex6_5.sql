/*
CREATE TABLE employee(
	Fname VARCHAR(200),
	Minit VARCHAR(200),
	LName VARCHAR(200),
	Ssn INT,
	Bdate DATE,
	Address VARCHAR(400),
	Sex VARCHAR(10),
	Salary INTEGER,
	Super_ssn INT,
	Dno INT,
	PRIMARY KEY (Ssn),
	FOREIGN KEY (Super_ssn) REFERENCES employee(Ssn));


CREATE TABLE department(
	Dname VARCHAR(200),
	Dnumber INT,
	Mgr_ssn INT,
	Mgr_start_date DATE,
	PRIMARY KEY (Dnumber),
	FOREIGN KEY (Mgr_ssn) REFERENCES employee(Ssn));

CREATE TABLE dept_locations(
	Dnumber INT,
	Dlocation VARCHAR(200),
	PRIMARY KEY(Dnumber,Dlocation),
	FOREIGN KEY (Dnumber) REFERENCES department(Dnumber));

CREATE TABLE project(
	Pname VARCHAR(200),
	Pnumber INT,
	Plocation VARCHAR(200),
	Dnum INT,
	PRIMARY KEY (Pnumber),
	FOREIGN KEY (Dnum) REFERENCES department(Dnumber));

CREATE TABLE works_on(
	Essn INT,
	Pno INT,
	Hours INT,
	PRIMARY KEY(Essn,Pno),
	FOREIGN KEY(Essn) REFERENCES employee(Ssn),
	FOREIGN KEY(Pno) REFERENCES project(Pnumber));

CREATE TABLE dependent(
	Essn INT,
	Dependent_name VARCHAR(400),
	Sex VARCHAR(10),
	Bdate DATE,
	Relationship VARCHAR(400),
	PRIMARY KEY(Essn,Dependent_name),
	FOREIGN KEY(Essn) REFERENCES employee(Ssn));
*/




Exercicio 5.1

a)
SELECT Essn,Pname,Fname 
FROM works_on
		JOIN project ON Pno=Pnumber
		JOIN employee ON Essn=Ssn

b)
SELECT Fname
FROM employee 
	JOIN (SELECT Ssn AS SSsn
		FROM employee
		WHERE Fname='Carlos' AND Minit='D' AND Lname='Gomes') AS pasta ON Super_ssn=SSsn

c)
SELECT Pname,SUM(Hours) AS TotalHoras
FROM project
		JOIN works_on ON Pnumber=Pno
GROUP BY Pname

d)
SELECT Fname, Hours
FROM project
		JOIN works_on ON Pnumber=Pno
		JOIN employee ON Ssn=Essn
WHERE Hours>20 AND Dno=3 AND Pname='Aveiro Digital'

e)
SELECT Fname
FROM employee
		LEFT outer JOIN works_on ON Ssn=Essn
WHERE Essn IS NULL

f)
SELECT Dname, AVG(Salary) AS avg_salary
FROM department
		JOIN employee ON Dnumber=Dno
WHERE Sex='F'
GROUP BY Dname

g)
SELECT Fname, Lname, COUNT(Essn) AS cnt
FROM employee
		JOIN dependent ON Ssn=Essn
GROUP BY Fname,Lname
HAVING cnt>1

h)
SELECT Ssn
FROM department
		JOIN employee ON Mgr_ssn=Ssn
		LEFT outer JOIN dependent ON Essn=Ssn
WHERE Dependent_name IS NULL

i)
SELECT Fname, Lname, Address
FROM department
		LEFT outer JOIN dept_locations ON department.Dnumber=dept_locations.Dnumber
		JOIN employee ON Dno=department.Dnumber
		JOIN works_on ON Ssn=Essn
		JOIN project ON Pno=Pnumber
WHERE Plocation = 'Aveiro' AND Dlocation!='Aveiro'
