-- a)
--  SELECT * FROM authors;

-- b)
-- SELECT au_fname, au_lname, phone FROM authors;


-- c)
--SELECT au_fname, au_lname, phone FROM authors
--ORDER BY au_fname, au_lname;

-- d)
--SELECT au_fname AS first_name, au_lname AS last_name, phone AS telephone FROM authors
--ORDER BY au_fname, au_lname;

-- e)
--SELECT au_fname AS first_name, au_lname AS last_name, phone AS telephone
--FROM authors WHERE state='CA' AND NOT au_lname='Ringer'
--ORDER BY au_fname, au_lname;

--F) SELECT * FROM publishers WHERE pub_name LIKE '%Bo%';

--G)
/*SELECT DISTINCT pub_name 
FROM publishers INNER JOIN
	(SELECT pub_id
	FROM titles 
	WHERE type='business') as XY ON XY.pub_id=publishers.pub_id;*/

--H)
/*SELECT titles.pub_id,COUNT(titles.pub_id) AS CNT
FROM titles JOIN sales ON sales.title_id=titles.title_id
GROUP BY titles.pub_id;
*/

--I)
/*SELECT titles.pub_id,titles.title_id,COUNT(titles.pub_id) AS CNT
FROM titles JOIN sales ON sales.title_id=titles.title_id
GROUP BY titles.pub_id,titles.title_id;*/

-- j)
--SELECT title FROM titles JOIN (
--	SELECT title_id
--	FROM (sales JOIN stores ON sales.stor_id=stores.stor_id) 
--	WHERE stor_name='Bookbeat') AS tmp ON tmp.title_id=titles.title_id;

--k)
--SELECT au_fname, au_lname 
--	FROM titles JOIN authors JOIN titleauthor
--		ON authors.au_id=titleauthor.au_id
--		ON titleauthor.title_id=titles.title_id
--	GROUP BY au_fname, au_lname
--		HAVING COUNT(DISTINCT type)>1;

--L)
/*SELECT type,pub_id,AVG(price) AS AvgPrice ,COUNT(title_id) AS SaleNum 
FROM titles
GROUP BY type,pub_id;
*/

--M)
/*SELECT DISTINCT title
FROM titles
	JOIN (SELECT type, AVG(advance) AS avgAdv
	FROM titles
	GROUP BY type) AS quinoa ON titles.type=quinoa.type
WHERE advance>avgAdv*1.5
*/
mete e

--N)
/*SELECT titles.title,authors.au_fname+' '+authors.au_lname AS author,SUM(sales.qty)*titles.price/(titles.royalty*titleauthor.royaltyper/100.0) AS MoneyMade
FROM sales
	JOIN titles ON titles.title_id=sales.title_id
	JOIN titleauthor ON titles.title_id=titleauthor.title_id
	JOIN authors ON authors.au_id=titleauthor.au_id
GROUP BY titles.title_id,titles.title,titles.price,titles.royalty,titleauthor.au_id,authors.au_fname,authors.au_lname,titleauthor.royaltyper;
*/
		
-- o)
--SELECT ytd_sales AS sales, title, 
--ytd_sales*price AS total_money,
--cast(ytd_sales*price*(royalty/100.0) as numeric(36,4)) AS authors_money,
--cast(ytd_sales*price*((100-royalty)/100.0) as numeric(36,4)) AS publisher_money
--	FROM titles
--	GROUP BY ytd_sales, title, price, royalty
--	ORDER BY ytd_sales DESC;

--P)
/*SELECT ytd_sales AS sales, title, authors.au_fname+' '+authors.au_lname AS author, SUM(sales.qty)*titles.price/(titles.royalty*titleauthor.royaltyper/100.0) AS AuthorMoney, SUM(sales.qty)*titles.price/(100-titles.royalty) AS PublisherMoney
FROM titles
	JOIN titleauthor ON titles.title_id=titleauthor.title_id
	JOIN authors ON titleauthor.au_id=authors.au_id
	JOIN sales ON titles.title_id=sales.title_id
GROUP BY titles.title_id,titles.title,titles.price,titles.ytd_sales,titles.royalty,titleauthor.au_id,authors.au_fname,authors.au_lname,titleauthor.royaltyper
ORDER BY ytd_sales DESC
*/

-- q) 
--SELECT DISTINCT stores.stor_id
--FROM stores
--	JOIN sales ON sales.stor_id=stores.stor_id
--GROUP BY stores.stor_id
--HAVING COUNT(sales.title_id) = (SELECT COUNT(titles.title_id)
--								FROM titles)

--R)
/*SELECT *
FROM	(SELECT sales.stor_id,COUNT(sales.stor_id) AS NumSales
		FROM stores JOIN sales ON sales.stor_id=stores.stor_id
		GROUP BY sales.stor_id) AS John
WHERE NumSales > (SELECT AVG(NumSales)
					FROM	(SELECT sales.stor_id,COUNT(sales.stor_id) AS NumSales
					FROM stores JOIN sales ON sales.stor_id=stores.stor_id
					GROUP BY sales.stor_id) AS John);
*/


-- s)
--SELECT title
--	FROM titles LEFT JOIN sales JOIN stores
--		ON stores.stor_id=sales.stor_id
--		ON sales.title_id=titles.title_id
--EXCEPT
--SELECT title
--	FROM titles JOIN sales JOIN stores
--		ON sales.stor_id = stores.stor_id
--		ON titles.title_id=sales.title_id
--		WHERE stor_name='Bookbeat';


