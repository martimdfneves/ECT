CREATE TABLE employee(
	Fname VARCHAR(200),
	Minit VARCHAR(200),
	LName VARCHAR(200),
	Ssn INT,
	Bdate DATE,
	Address VARCHAR(400),
	Sex VARCHAR(10),
	Salary INTEGER,
	Super_ssn INT,
	Dno INT,
	PRIMARY KEY (Ssn),
	FOREIGN KEY (Super_ssn) REFERENCES employee(Ssn));


CREATE TABLE department(
	Dname VARCHAR(200),
	Dnumber INT,
	Mgr_ssn INT,
	Mgr_start_date DATE,
	PRIMARY KEY (Dnumber),
	FOREIGN KEY (Mgr_ssn) REFERENCES employee(Ssn));

CREATE TABLE dept_locations(
	Dnumber INT,
	Dlocation VARCHAR(200),
	PRIMARY KEY(Dnumber,Dlocation),
	FOREIGN KEY (Dnumber) REFERENCES department(Dnumber));

CREATE TABLE project(
	Pname VARCHAR(200),
	Pnumber INT,
	Plocation VARCHAR(200),
	Dnum INT,
	PRIMARY KEY (Pnumber),
	FOREIGN KEY (Dnum) REFERENCES department(Dnumber));

CREATE TABLE works_on(
	Essn INT,
	Pno INT,
	Hours INT,
	PRIMARY KEY(Essn,Pno),
	FOREIGN KEY(Essn) REFERENCES employee(Ssn),
	FOREIGN KEY(Pno) REFERENCES project(Pnumber));

CREATE TABLE dependent(
	Essn INT,
	Dependent_name VARCHAR(400),
	Sex VARCHAR(10),
	Bdate DATE,
	Relationship VARCHAR(400),
	PRIMARY KEY(Essn,Dependent_name),
	FOREIGN KEY(Essn) REFERENCES employee(Ssn));