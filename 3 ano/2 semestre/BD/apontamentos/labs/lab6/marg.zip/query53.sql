-- 5.3
-- a)
--SELECT paciente.nome
--FROM paciente left outer JOIN prescricao
--ON paciente.numUtente=prescricao.numUtente
--WHERE numPresc IS NULL

-- b)
--SELECT especialidade, count(medico.especialidade) AS contagem
--FROM medico JOIN prescricao
--ON numMedico=numSNS
--GROUP BY especialidade

--c)
--SELECT prescricao.farmacia, count(farmacia) AS cnt
--FROM prescricao RIGHT outer JOIN farmacia
--ON farmacia=nome
--GROUP BY farmacia;

--d)
--SELECT farmaco.nome 
--FROM farmaco LEFT outer JOIN presc_farmaco
--ON nome=nomeFarmaco
--WHERE numPresc IS NULL

--e)
--SELECT prescricao.farmacia, presc_farmaco.numRegFarm, count(numRegFarm) AS CountFarmacos
--FROM presc_farmaco JOIN prescricao
--ON prescricao.numPresc=presc_farmaco.numPresc
--WHERE farmacia IS NOT NULL
--GROUP BY farmacia, numRegFarm

--f)
--SELECT pizza.numUtente
--FROM prescricao AS pizza,
--		 prescricao AS salsa
--WHERE pizza.numUtente=salsa.numUtente AND pizza.numMedico!=salsa.numMedico;




  