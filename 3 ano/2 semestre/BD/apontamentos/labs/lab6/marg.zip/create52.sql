create table produto(
	codigo INT PRIMARY KEY,
	nome VARCHAR(50),
	preco FLOAT,
	iva FLOAT,
	unidades INT
);



create table tipo_fornecedor(
	codigo INT PRIMARY KEY,
	designacao VARCHAR(20)
);

create table fornecedor(
	nif INT PRIMARY KEY,
	nome VARCHAR(50),
	fax INT,
	endereco VARCHAR(100),
	condpag INT,
	tipo  INT FOREIGN KEY REFERENCES tipo_fornecedor(codigo)
);

create table encomenda(
	numero INT PRIMARY KEY,
	data DATE,
	fornecedor INT FOREIGN KEY REFERENCES fornecedor(nif)
);

create table item(
	numEnc INT FOREIGN KEY REFERENCES encomenda(numero),
	codProd INT FOREIGN KEY REFERENCES produto(codigo),
	unidades INT,
	PRIMARY KEY(numEnc, codProd)
);
