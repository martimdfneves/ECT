-- 5.2
-- a)
--SELECT fornecedor.nome
--	FROM fornecedor LEFT JOIN encomenda
--	ON encomenda.fornecedor=fornecedor.nif
--	WHERE encomenda.fornecedor IS NULL;

-- b)
--SELECT nome, avg(item.unidades) AS avg_item
--FROM produto JOIN item
--	ON codigo=codProd
--GROUP BY nome, codProd

-- c)
--SELECT (count(numEnc)+0.0)/(count(DISTINCT numEnc)+0.0) AS count
--FROM produto JOIN item
--ON  codigo=codProd

-- d)
--SELECT fornecedor.nome AS fornecedor, produto.nome AS produto, item.unidades
--FROM fornecedor JOIN encomenda ON fornecedor=nif
--	JOIN item ON numEnc=numero
--	JOIN produto ON codProd=codigo
	
  
